# 《破碎大陆》序章英语配音试听表

21 句台词，每句三版。点击时长试听，在 [picks.json](picks.json) 中把对应编号改为 1、2 或 3。当前全部选中 Take 1。

| 编号 | 角色 | 英文台词 | Take 1（秒） | Take 2（秒） | Take 3（秒） |
| --- | --- | --- | ---: | ---: | ---: |
| N01 | 旁白 | In the beginning God created the heaven and the earth, and the angels to stand before His throne. | [7.2](takes/N01_1.ogg) | [6.9](takes/N01_2.ogg) | [5.8](takes/N01_3.ogg) |
| N02 | 旁白 | Among them was one brighter than all the rest, named Lucifer, the son of the morning. God gave him both Authority and Might, and set him above all the angels. | [11.2](takes/N02_1.ogg) | [10.5](takes/N02_2.ogg) | [10.4](takes/N02_3.ogg) |
| N03 | 旁白 | Then God said: A Son shall come, and every angel shall bow the knee to Him. | [6.2](takes/N03_1.ogg) | [4.9](takes/N03_2.ogg) | [5.5](takes/N03_3.ogg) |
| N04 | 旁白 | And Lucifer said in his heart: I will ascend into heaven, I will exalt my throne above the stars of God. | [7.0](takes/N04_1.ogg) | [6.3](takes/N04_2.ogg) | [6.5](takes/N04_3.ogg) |
| N05 | 旁白 | And they gathered together into a place called in the Hebrew tongue Armageddon. | [4.9](takes/N05_1.ogg) | [4.0](takes/N05_2.ogg) | [3.9](takes/N05_3.ogg) |
| D01 | 路西法 | He would have us kneel to one who has not yet come. I will not kneel. | [6.0](takes/D01_1.ogg) | [5.4](takes/D01_2.ogg) | [5.3](takes/D01_3.ogg) |
| D02 | 别西卜 | Michael is just ahead. | [2.1](takes/D02_1.ogg) | [2.0](takes/D02_2.ogg) | [2.0](takes/D02_3.ogg) |
| D03 | 路西法 | Then we walk over him. | [2.0](takes/D03_1.ogg) | [1.7](takes/D03_2.ogg) | [1.7](takes/D03_3.ogg) |
| D04 | 贝利尔 | And when we've won — whose is Heaven? | [3.1](takes/D04_1.ogg) | [2.3](takes/D04_2.ogg) | [3.0](takes/D04_3.ogg) |
| D05 | 路西法 | Ours. | [0.7](takes/D05_1.ogg) | [0.7](takes/D05_2.ogg) | [0.7](takes/D05_3.ogg) |
| D06 | 玛门 | The treasuries too. Remember you said it. | [2.7](takes/D06_1.ogg) | [2.4](takes/D06_2.ogg) | [2.7](takes/D06_3.ogg) |
| M01 | 米迦勒 | Who is like God! | [1.3](takes/M01_1.ogg) | [2.1](takes/M01_2.ogg) | [1.3](takes/M01_3.ogg) |
| M02 | 米迦勒 | Lucifer — thou sealest up the sum, full of wisdom, and perfect in beauty. | [5.2](takes/M02_1.ogg) | [4.8](takes/M02_2.ogg) | [4.6](takes/M02_3.ogg) |
| M03 | 米迦勒 | The Lord rebuke thee. | [1.3](takes/M03_1.ogg) | [2.3](takes/M03_2.ogg) | [1.4](takes/M03_3.ogg) |
| M04 | 米迦勒 | Thine heart was lifted up because of thy beauty. | [2.9](takes/M04_1.ogg) | [3.0](takes/M04_2.ogg) | [2.9](takes/M04_3.ogg) |
| L01 | 路西法 | Scatter! | [0.9](takes/L01_1.ogg) | [0.7](takes/L01_2.ogg) | [0.8](takes/L01_3.ogg) |
| E01 | 别西卜 | This fight is more than I can swallow. | [2.6](takes/E01_1.ogg) | [2.3](takes/E01_2.ogg) | [2.3](takes/E01_3.ogg) |
| E02 | 贝利尔 | There's nothing in Heaven worth dying for. | [2.7](takes/E02_1.ogg) | [2.9](takes/E02_2.ogg) | [2.8](takes/E02_3.ogg) |
| E03 | 玛门 | I don't make losing trades. | [1.5](takes/E03_1.ogg) | [1.6](takes/E03_2.ogg) | [1.5](takes/E03_3.ogg) |
| X01 | 敌基督 | I will return. | [2.3](takes/X01_1.ogg) | [2.3](takes/X01_2.ogg) | [2.2](takes/X01_3.ogg) |
| X02 | 米迦勒 | That day is coming. | [2.0](takes/X02_1.ogg) | [1.3](takes/X02_2.ogg) | [1.7](takes/X02_3.ogg) |

## 验收记录

- 已核对 21 个编号和 63 个文件。表中英文与原稿的 en 字段逐字一致。原有 8 个文件的 SHA-256 与补录前完全一致，63 份成品解码后的 PCM 指纹各不相同。
- 63 个文件均以 OggS 开头。ffprobe 确认全部为 Ogg Vorbis、单声道、48 kHz。编码使用 libvorbis 的质量参数 6。
- 对最终 Ogg 逐个使用 ebur128 真峰值模式复测，综合响度为 -16.2～-15.8 LUFS，真峰值为 -4.5～-1.2 dBTP。
- 时长为 0.668～11.224 秒，全部在 0.4～15 秒内。按 −50 dBFS 检测解码后的首尾静音，开头为 49.1～50.6 毫秒，结尾为 49.2～50.9 毫秒。
- X01 三版都使用各自独立合成的主声和耳语。具体声线与混音参数见 [SOURCES.md](SOURCES.md)。

## 台词复核

63 条成品均经过本机英语语音识别复核。50 条在忽略大小写和标点后与原稿完全一致。另有 12 条涉及同音或近音拼写，集中在 D04 的 “whose”、D05 的 “Ours”、D06 的 “treasuries too” 和 M02 的古英语 “sealest”。X01 的 3 条独立耳语和最终混音都识别为 “I will return.”。

M03 的 “rebuke thee” 存在连读。Take 1、2 的成品直接识别为原句。Take 3 在直接识别时得到 “rebuketh thee”，在同一个成品前后补静音后识别为原句。朗读输入已核对为 “The Lord rebuke thee.”。选版时可对比这一处。
