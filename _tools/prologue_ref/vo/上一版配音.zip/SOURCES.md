# 《破碎大陆》序章英语配音来源

本批录音生成于 2026-11-22（Asia/Singapore）。63 个成品中，原有 8 个来自 [OpenAI.fm](https://www.openai.fm/)，本次补录的 55 个来自本机离线运行的 [Qwen3-TTS](https://github.com/QwenLM/Qwen3-TTS)。55 个新增成品以独立采样生成，X01 另录了 3 条独立耳语。

## 角色与音色参考

| 角色 | 简报声线 | 成品使用的声线及参考 |
| --- | --- | --- |
| 旁白 narrator | fable | N01～N05 的 Take 1 为 OpenAI fable。各句 Take 2、3 分别以该句的 Take 1 为音色和朗读参考。 |
| 路西法 lucifer | ash | D01、D05 的 Take 1 为 OpenAI ash。补录以 D01_1 为同一角色的音色参考。D05 的备选另用原版 D05_1 对齐单词 “Ours.” 的发音。L01 的短促命令另有按该句指令合成的表演参考。 |
| 别西卜 beelzebub | ballad | D02 的 Take 1 为 OpenAI ballad。其余录音以 D02_1 为音色参考。 |
| 米迦勒 michael | onyx | Qwen3 按米迦勒的角色基调和 M02 指令设计声音。M02_1 成为该角色的固定音色参考，M01 的战吼另有按该句指令合成的表演参考。M03 的补录对多版 “rebuke thee” 做了独立的词尾复核。 |
| 贝利尔 belial | sage | Qwen3 按贝利尔的角色基调和 D04 指令设计声音，使用 D04_1 作为固定音色参考。 |
| 玛门 mammon | verse | Qwen3 按玛门的角色基调和 D06 指令设计声音，使用 D06_1 作为固定音色参考。 |
| 敌基督 antichrist | ash | 以路西法 D01_1 为音色参考，主声采用 X01 的角色基调与表演指令。耳语单独合成。 |

## 合成与后期

- OpenAI.fm 页面标示的模型为 GPT-4o mini TTS，网页未显示其快照版本。原有 8 个成品的文件指纹均与补录前一致。
- 本机使用 qwen-tts 0.1.1。角色样音与指定的表演参考使用 [Qwen3-TTS-12Hz-1.7B-VoiceDesign](https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign)。参考音色合成使用 [Qwen3-TTS-12Hz-0.6B-Base](https://huggingface.co/Qwen/Qwen3-TTS-12Hz-0.6B-Base)。两个主权重文件的 SHA-256 前 16 位分别为 `391e8db219f292c5` 和 `180b3b10eb1c9f1b`。
- 朗读输入取自每条台词的 en 字段。表演指令单独传入，使用简报中的角色基调加一个空格，再接该句的 direction。耳语使用 `whispering, breathy, almost inaudible`。
- X01 每个 take 将主声和对应耳语分别降调三个半音，主声语速保持原速。耳语与主声对齐，按均方根电平混至主声下方 12 dB。暗色卷积混响使用 55 毫秒预延迟，脉冲响应衰减时长为 2.5 秒。干声与混响返回的均方根电平先行匹配，再按 70∶30 混合，以保留辅音的清晰度。
- 最终编码使用 libvorbis，质量参数 6，单声道、48 kHz。试听链接和对成品的实测结果见 [REVIEW.md](REVIEW.md)。

## AI 配音声明

全套 63 个成品均为 AI 生成。全套可使用以下英文声明。

> The English voice-over in the prologue is AI-generated using OpenAI text-to-speech and Qwen3-TTS. No human performer recorded these lines.

原简报指定的以下声明适用于 OpenAI.fm 生成的 8 个成品。

> The English voice-over in the prologue is AI-generated (OpenAI text-to-speech); it is not a human voice.

