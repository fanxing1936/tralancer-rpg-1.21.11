# idle @ 6/20 秒；实际bbmodel烘焙，非玩法。
