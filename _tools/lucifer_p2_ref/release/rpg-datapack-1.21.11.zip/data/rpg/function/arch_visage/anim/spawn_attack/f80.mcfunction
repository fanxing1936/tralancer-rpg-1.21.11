# spawn_attack @ 80/20 秒；实际bbmodel烘焙，非玩法。
