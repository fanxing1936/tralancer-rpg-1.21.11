execute if score @s rpg_av_t matches ..29 run return run function rpg:arch_visage/anim/spawn_attack/at_a_b_a_a
function rpg:arch_visage/anim/spawn_attack/at_a_b_a_b
