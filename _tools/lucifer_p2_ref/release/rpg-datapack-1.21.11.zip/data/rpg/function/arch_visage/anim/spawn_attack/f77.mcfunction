# spawn_attack @ 77/20 秒；实际bbmodel烘焙，非玩法。
