# sk3_1 的外观与音效。由 add_abaddon_model.py 生成。
function rpg:abaddon/anim/enter/spread
execute at @s run playsound rpg:abaddon.strike hostile @a[distance=..32] ~ ~ ~ 1.2 1
