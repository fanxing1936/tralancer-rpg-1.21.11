function rpg:campaign/beelzebub/ui/scene/clear
execute positioned ^ ^ ^12 run summon minecraft:item_display ~0.00 ~0.12 ~0.00 {Tags:["rpg.ch1.scene","rpg.ch1.ui.prop","rpg.ch1.trail1.prop","rpg.ch1.ui.new"],item:{id:"minecraft:wheat_seeds",count:1},item_display:"fixed",view_range:0.3f,shadow_radius:0.18f,shadow_strength:0.55f,transformation:{translation:[0f,0f,0f],scale:[0.38f,0.38f,0.38f],left_rotation:[0f,0f,0.0872f,0.9962f],right_rotation:[0f,0f,0f,1f]}}
scoreboard players operation @e[type=minecraft:item_display,tag=rpg.ch1.ui.new,sort=nearest,limit=1,distance=..72] rpg_ch1_id = @s rpg_ch1_id
tag @e[type=minecraft:item_display,tag=rpg.ch1.ui.new,sort=nearest,limit=1,distance=..72] remove rpg.ch1.ui.new
