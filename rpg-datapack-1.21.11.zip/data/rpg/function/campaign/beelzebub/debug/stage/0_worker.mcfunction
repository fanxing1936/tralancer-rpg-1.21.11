function rpg:campaign/beelzebub/debug/stage_reset
tag @s add rpg.ch1.debug.no_commit
scoreboard players set @s rpg_ch1_stage 0
function rpg:campaign/beelzebub/stage/0_enter
