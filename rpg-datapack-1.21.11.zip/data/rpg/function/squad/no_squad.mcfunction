function rpg:hud/m11
playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 1.2
