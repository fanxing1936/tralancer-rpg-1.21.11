execute if entity @s[tag=rpg.name.1] run return 0
execute if entity @s[tag=rpg.clue.1.1] run return 0
tag @s add rpg.clue.1.1
scoreboard players add @s rpg_ex_xp 4
function rpg:inquest/recount/1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.7 1.45
tellraw @s ["",{"text":"[罪证] ","color":"#DAA520","bold":true,"italic":false},{"text":"路西法 · ","color":"#5FD68C","bold":false,"italic":false},{"text":"蛇矛总从高处落下，力量依赖俯视。","color":"gray","italic":false},{"text":"　进度 ","color":"dark_gray","italic":false},{"score":{"name":"@s","objective":"rpg_case1"},"color":"white","italic":false},{"text":"/3","color":"dark_gray","italic":false}]
execute if score @s rpg_case1 matches 3.. run function rpg:inquest/reveal/1
