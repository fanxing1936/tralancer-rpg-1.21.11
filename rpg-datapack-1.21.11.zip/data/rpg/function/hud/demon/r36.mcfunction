$title @s actionbar ["",{"text":"\uf023\uf063\uf0a3\uf0e3","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf123","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
