$title @s actionbar ["",{"text":"\uf014\uf054\uf094\uf0d4","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf114","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
