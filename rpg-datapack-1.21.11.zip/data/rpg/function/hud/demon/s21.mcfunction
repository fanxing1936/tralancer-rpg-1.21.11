title @s actionbar ["",{"text":"\uf014\uf054","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf114","font":"rpg:combat_prompt"},{"text":"\uf214","font":"rpg:combat_prompt"}]
