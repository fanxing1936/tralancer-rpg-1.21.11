$title @s actionbar ["",{"text":"\uf01e\uf05e\uf09e\uf0de","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf11e","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
