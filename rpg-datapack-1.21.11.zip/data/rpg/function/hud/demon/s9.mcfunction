title @s actionbar ["",{"text":"\uf008\uf048","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf108","font":"rpg:combat_prompt"},{"text":"\uf208","font":"rpg:combat_prompt"}]
