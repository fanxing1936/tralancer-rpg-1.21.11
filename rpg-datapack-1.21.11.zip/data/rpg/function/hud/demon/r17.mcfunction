$title @s actionbar ["",{"text":"\uf010\uf050\uf090\uf0d0","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf110","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
