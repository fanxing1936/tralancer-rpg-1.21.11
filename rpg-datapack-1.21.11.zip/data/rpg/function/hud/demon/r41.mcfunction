$title @s actionbar ["",{"text":"\uf028\uf068","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf128","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
