title @s actionbar ["",{"text":"\uf019\uf059","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf119","font":"rpg:combat_prompt"},{"text":"\uf219","font":"rpg:combat_prompt"}]
