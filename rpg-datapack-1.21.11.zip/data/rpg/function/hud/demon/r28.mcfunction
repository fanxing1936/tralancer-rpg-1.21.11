$title @s actionbar ["",{"text":"\uf01b\uf05b\uf09b\uf0db","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf11b","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
