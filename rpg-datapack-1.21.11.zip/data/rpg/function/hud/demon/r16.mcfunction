$title @s actionbar ["",{"text":"\uf00f\uf04f\uf08f\uf0cf","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf10f","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
