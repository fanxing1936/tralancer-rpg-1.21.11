$title @s actionbar ["",{"text":"\uf002\uf042\uf082\uf0c2","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf102","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
