scoreboard players set @s rpg_hud_dm 44
scoreboard players set @s rpg_hud_dmt 50
