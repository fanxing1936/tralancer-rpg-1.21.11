$title @s actionbar ["",{"text":"\uf007\uf047\uf087\uf0c7","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf107","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
