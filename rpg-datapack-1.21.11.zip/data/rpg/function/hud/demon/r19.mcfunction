$title @s actionbar ["",{"text":"\uf012\uf052\uf092\uf0d2","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf112","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
