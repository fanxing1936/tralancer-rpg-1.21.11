$title @s actionbar ["",{"text":"\uf012\uf052","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf112","font":"rpg:combat_prompt"},$(a),$(b),$(c),$(d)]
