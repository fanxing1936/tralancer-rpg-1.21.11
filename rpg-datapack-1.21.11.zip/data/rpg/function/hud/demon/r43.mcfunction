$title @s actionbar ["",{"text":"\uf02a\uf06a\uf0aa\uf0ea","font":"rpg:combat_prompt","italic":false,"color":"white"},{"text":"\uf12a","font":"rpg:combat_prompt"},$(r),$(a),$(b),$(c),$(d)]
